<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Colegio Secundario N°60</title>
    <link rel="icon" href="eda19a43-f894-4d4c-9a39-09282b372e93.ico" type="image/icon">
    <meta name='viewport' content='width=device-width, initial-scale=1'>
   <link rel="stylesheet" href="styles.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-brand">
        <h1>Colegio Secundario N°60</h1>
        <button class="hamburger" id="hamburger">&#9776;</button>
    </div>
    <ul class="navbar-menu" id="nav-menu">
        <li><a href="#">Plan de Estudio</a></li>
        <li><a href="#">Profesores</a></li>
        <li><a href="#">Biblioteca</a></li>
        <li><a href="#">Promos</a></li>
        <li><a href="#">Historia del colegio</a></li>
        <li><a href="#">Proyectos</a></li>
        <li><a href="#">Preguntas Frecuentes</a></li>
    </ul>
</nav>


    <div class="hero-image">
        <img src="https://i.ibb.co/zhG8mHQ3/colegio.jpg" alt="Frente del colegio">
    </div>
    <!-- Ventana flotante de noticias -->
    <div class="floating-news" id="newsBox">
    <button onclick="cerrarNoticia()" class="close-btn">X</button>
    <img src="https://i.ibb.co/6RDyT929/viaje.jpg" alt="Noticia destacada">
    <h3>¡Nueva Aula Digital!</h3>
    <p>Se inauguró un nuevo espacio con computadoras para todos los cursos.</p>
</div>

    <!-- Sección Promos -->
    <div class="section-row">
    <section class="section" id="promos">
        <h2>Promociones Escolares</h2>
        <p>Aquí podrás ver las promociones del colegio a lo largo de los años.</p>
        <img src="https://i.ibb.co/QF20nb06/promo.jpg">
    </section>

    <section class="section" id="proyectos">
        <h2>Proyectos</h2>
        <p>Conocé los proyectos destacados realizados por los alumnos.</p>
        <img src="https://i.ibb.co/6RDyT929/viaje.jpg">
    </section>
</div>

   
    <section class="section noticia-completa" id="noticia-completa">
    <h2>Noticia Destacada</h2>
    <div class="noticia-img-wrapper">
        <img src="https://i.ibb.co/QF20nb06/promo.jpg" alt="Noticia Destacada">
    </div>
    <p>El colegio continúa apostando a la tecnología con una nueva aula digital totalmente equipada, brindando a los estudiantes mejores herramientas para su aprendizaje.</p>
</section>

    <!-- Sección Mapa -->
    <section class="section-mapa" id="mapa">
    <h2>Dónde nos encontramos</h2>
    <div class="mapa-container">
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d859.4918532693098!2d-64.86064551990309!3d-24.241516337779267!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e1!3m2!1ses!2sar!4v1746725352104!5m2!1ses!2sar" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
        
    </iframe>
    </div>
</section>


    
    <footer>
        <div class="container">
            <div class="row">
                <div>
                    <h4>Contacto</h4>
                    <p><strong>Correo Electrónico:</strong> ColegioSecundarioN°60@gmail.com</p>
                    <p><strong>Teléfono:</strong> (sin definir)</p>
                </div>
                <div>
                    <h4>Ubicación</h4>
                    <p><strong>Dirección:</strong> Avenida Pablo Balduin S/N - Nueva Ciudad</p>
                </div>
                <div>
                    <h4>Horarios de Atención</h4>
                    <p><strong>Lunes a Viernes:</strong> 7:30 AM - 18:30 PM</p>
                </div>
            </div>
            <hr>
        </div>
    </footer>

</body>

<script>
    function cerrarNoticia() {
        document.getElementById("newsBox").style.display = "none";
    }

    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');

    hamburger.addEventListener('click', () => {
        navMenu.classList.toggle('show');
    });


</script>
</html>